class secuencial{
    regresar(){
        window.history.back();
    }
//11.Suma de dos números: Escribe un programa que tome dos números como entrada y muestre su suma.
sum2num() {
    let num = parseFloat(document.getElementById("num").value);
    let num1 = parseFloat(document.getElementById("num1").value);
    let resp = num + num1;
    document.getElementById("resp").textContent = "La suma de " + num + " y " + num1 + " es igual a: " + resp;
}



//12.Área de un triángulo: Pide al usuario que ingrese la base y la altura de un triángulo, luego calcula y muestra su área.
triangulo() {
    let num1 = parseFloat(document.getElementById("num1").value);
    let num2 = parseFloat(document.getElementById("num2").value);
    let resp = (num1 * num2) / 2;
    document.getElementById("resp").textContent = "El área del triángulo es: " + resp;
}

//13.Número par o impar: Solicita al usuario que ingrese un número e indica si es par o impar.
parimpar() {
    let num = parseFloat(document.getElementById("num").value);
    if (num % 2 === 0) {
        document.getElementById("resp").textContent = "El número " + num + " es par.";
    } else {
        document.getElementById("resp").textContent = "El número " + num + " es impar.";
    }
}


//14.Calculadora simple: Crea una calculadora que realice operaciones básicas como suma, resta, multiplicación y división, según la elección del usuario.
calculadorasimple() {
            let num1 = parseFloat(document.getElementById("num").value);
            let num2 = parseFloat(document.getElementById("num1").value);
            let operador = document.getElementById("operator").value;
            let resultado;
            switch (operador) {
                case "+":
                    resultado = num1 + num2;
                    break;
                case "-":
                    resultado = num1 - num2;
                    break;
                case "*":
                    resultado = num1 * num2;
                    break;
                case "/":
                    if (num2 !== 0) {
                        resultado = num1 / num2;
                    } else {
                        resultado = "Error: No se puede dividir por cero";
                    }
                    break;
                default:
                    resultado = "Operación no válida";
            }
            document.getElementById("resp").textContent = "Resultado: " + resultado;
        }


//15.Tabla de multiplicar: Pide al usuario un número y muestra su tabla de multiplicar del 1 al 10.
tablamul() {
        let num = parseInt(document.getElementById("num").value);
        let resultado = "";
        if (num >= 1 && num <= 10) {
            for (let producto = 1; producto <= 10; producto++) {
                resultado += num + " x " + producto + " = " + num * producto + "<br>";
            }
        } else {
            resultado = "El número debe estar entre 1 y 10 para mostrar la tabla de multiplicar.";
        }
        document.getElementById("resp").innerHTML = resultado;
    }
    


//16.Copiar palabra: Escribe un programa que lea dos palabras y concatena en otra variable las dos palabras
palabracop(){
    let palabra1 = document.getElementById("palabra1").value;
    let palabra2 = document.getElementById("palabra2").value;
    let resultado = palabra1 + " " + palabra2;
    document.getElementById("resp").textContent = "La concatenación de las dos palabras es: " + resultado;
    }
}

const Ejercicios = new secuencial()