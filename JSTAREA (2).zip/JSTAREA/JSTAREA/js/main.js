class Numeros{

    regresar(){
        window.history.back();
    }
}