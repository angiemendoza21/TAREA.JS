class ciclos{
//41.Suma de números pares: Utiliza un bucle for para calcular la suma de los números pares del 1 al 50.
pares() {
    let suma = 0;
    let resultado = "";
    for (let i = 2; i <= 50; i += 2) {
        suma += i;
        resultado += i + "<br>";
    }
    document.getElementById("resp").innerHTML = "La suma de los números pares del 1 al 50 es: " + suma + "<br><br>" + resultado;
}


//42.Tabla de multiplicar: Utiliza un bucle for para imprimir la tabla de multiplicar de un número ingresado por el usuario del 1 al 12
multiplicar() {
    let num, producto;
    let resultado = "";
    num = document.getElementById("num").value
    if (num >= 1 && num <= 12) {
        for (producto = 1; producto <= 12; producto++) {
            resultado += num + " x " + producto + " = " + (num * producto) + "<br>";
        }
        document.getElementById("resp").innerHTML = resultado;
    } else {
        document.getElementById("resp").textContent = "El número debe estar entre 1 y 12 para mostrar la tabla de multiplicar.";
    }
}

//43.Contador de vocales: Utiliza un bucle while para contar el número de vocales en una palabra ingresada por el usuario.
vocales() {
    let pos = 0, cv = 0, frase, resp
    frase = document.getElementById("frase").value
    frase = frase.toLowerCase()
    while (pos < frase.length) {
        if (frase[pos] == 'a' || frase[pos] == 'e' || frase[pos] == 'i' || frase[pos] == 'o' || frase[pos] == 'u') {
            cv = cv + 1 // cv++
        }
        pos++
    }
    resp = document.getElementById("resp")
    resp.innerHTML = `cantidad vocales: ${cv}`
}

//44.Contador de digitos: Utiliza un bucle for para contar el numero de dígitos en una palabra ingresada por el usuario.
digitos(){
    let palabra = document.getElementById("digitos").value;
    let contador = 0;
    for (let i = 0; i < palabra.length; i++) {
        if (/[0-9]/.test(palabra.charAt(i))) {
            contador++;
        }
    }
    document.getElementById("resp").textContent = "La palabra '" + palabra + "' tiene " + contador + " dígitos.";
}

//45.Adivina el número: Genera un número aleatorio y pide al usuario que adivine el número. Utiliza un bucle while para repetir la solicitud hasta que adivine correctamente.
numero() {
    let numeroAleatorio = Math.floor(Math.random() * 100) + 1;
    let resp = document.getElementById("resp");
    let intentos = 0;
    const intentosMaximos = 3; 

    while (intentos < intentosMaximos) {
        let numeroUsuario = parseInt(prompt(`Adivina el número (entre 1 y 100). Intento ${intentos + 1}:`));
        if (isNaN(numeroUsuario)) {
            resp.textContent = "Por favor, ingresa un número válido.";
            continue;
        }
        intentos++;
        if (numeroUsuario < numeroAleatorio) {
            resp.textContent = "Demasiado bajo. Intenta de nuevo.";
        } else if (numeroUsuario > numeroAleatorio) {
            resp.textContent = "Demasiado alto. Intenta de nuevo.";
        } else {
            resp.textContent = `¡Felicidades! Has adivinado el número en ${intentos} intentos.`;
            return;
        }
    }
    resp.textContent = `¡Lo siento! Has agotado tus ${intentosMaximos} intentos. El número era ${numeroAleatorio}.`;
}

//46.Contador de Alfabeto: Utiliza un bucle for para contar el número de letras del alfabeto(a..z) en una palabra ingresada por el usuario.
alfabeto(){
        let palabra = document.getElementById("palabra").value;
        let contador = 0;
        for (let i = 0; i < palabra.length; i++) {
            let letra = palabra.charAt(i);
            if ((letra >= 'a' && letra <= 'z') || (letra >= 'A' && letra <= 'Z')) {
                contador++;
            }
        }
        document.getElementById("resp").textContent = "Número de letras del alfabeto en la palabra: " + contador;
    }


//47.Suma de números impares: Utiliza un bucle while para calcular la suma de los números impares del 1 al 100.
impares(){
    let num = 1;
    let suma = 0;
    const limite = 100;
    while (num <= limite) {
        if (num % 2 !== 0) {
            suma += num;
        }
        num++;
    }
    document.getElementById("resp").textContent = "La suma de los números impares del 1 al 100 es: " + suma;
}

//48.Contador de caracteres: Escribir un programa que lea una palabra y presenta cuantos caracteres hay en dicha palabra.
caracteres(){
        let palabra = document.getElementById("palabra").value;
        let longitud = palabra.length;
        document.getElementById("resp").textContent = "La palabra '" + palabra + "' tiene " + longitud + " caracteres.";
    }
    
//49.Suma de números: Pide al usuario que ingrese números enteros positivos uno por uno y utiliza un bucle while para calcular la suma de estos números. El ciclo debe terminar cuando el usuario ingrese un número negativo.
sumanum() {
    let numero;
    let suma = 0;

    do {
        numero = parseInt(prompt("Ingrese un número entero positivo. Ingrese un número negativo para finalizar:"));

        if (!isNaN(numero) && numero >= 0) {
            suma += numero;
        } else if (isNaN(numero)) {
            alert("Por favor, ingrese un número válido.");
        }
    } while (numero >= 0);

    document.getElementById("resp").textContent = "La suma de los números introducidos es " + suma + ".";
}


//50.Cuenta regresiva: Pide al usuario que ingrese un número entero positivo y utiliza un bucle while para mostrar una cuenta regresiva desde ese número hasta 1.
regresiva(){
    let numero = parseInt(document.getElementById("num").value);
    
    if (numero > 0) {
        let resultado = "";
        while (numero >= 1) {
            resultado += numero + "\n";
            numero--;
        }
        document.getElementById("resp").textContent = resultado;
    } else {
        document.getElementById("resp").textContent = "Por favor, ingrese un número entero positivo.";
    }
}


    regresar(){
        window.history.back();
    }
}
const ejercicio_ciclos = new ciclos()