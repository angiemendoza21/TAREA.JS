class selectivo{

    regresar(){
        window.history.back();
    }
    //17. Mayor de tres números: Solicita tres números y determina cuál es el mayor de ellos.
calcularMayor() {

        let num1 = parseFloat(document.getElementById("num1").value);
        let num2 = parseFloat(document.getElementById("num2").value);
        let num3 = parseFloat(document.getElementById("num3").value);
        let mayorNum;
        if (num1 >= num2 && num1 >= num3) {
            mayorNum = num1;
        } else if (num2 >= num1 && num2 >= num3) {
            mayorNum = num2;
        } else {
            mayorNum = num3;
        }
        document.getElementById("resp").textContent = "El mayor número es: " + mayorNum;
    }

    //18. Edad mínima para votar: Pregunta la edad del usuario y verifica si es elegible para votar (18 años o más).
    edadvotar() {
        let num1 = parseInt(document.getElementById("num").value);
        if (num1 < 18) {
            document.getElementById("resp").textContent = "Usted es menor de edad";
        } else {
            document.getElementById("resp").textContent = "Puede votar";
        }
    }

    //19. Calculadora de BMI: Crea un programa que calcule el índice de masa corporal (BMI) a partir del peso y la altura del usuario, y luego indique si está en una categoría de peso saludable.
    calculadoraBMI() {
        let bmi;
        let peso = parseFloat(document.getElementById("num").value);
        let altura = parseFloat(document.getElementById("num2").value);
        
        if (isNaN(peso) || isNaN(altura) || altura === 0) {
            document.getElementById("resp1").textContent = "Por favor, ingrese valores válidos para peso y altura.";
            return;
        }
    
        bmi = peso / (altura * altura);
        document.getElementById("resp1").textContent = "Su índice de masa corporal (BMI) es: " + bmi.toFixed(2);
    
        if (bmi < 18.5) {
            document.getElementById("resp").textContent = "Está bajo de peso.";
        } else if (bmi >= 18.5 && bmi < 24.9) {
            document.getElementById("resp").textContent = "Está en un peso saludable.";
        } else if (bmi >= 25 && bmi < 29.9) {
            document.getElementById("resp").textContent = "Tiene sobrepeso.";
        } else {
            document.getElementById("resp").textContent = "Tiene obesidad.";
        }
    }
    

    //20. Número positivo, negativo o cero: Pide al usuario que ingrese un número y muestra si es positivo, negativo o cero.
    positivoneg() {
        let num = parseFloat(document.getElementById("num").value);
        if (num > 0) {
            document.getElementById("resp").textContent = "El número es positivo.";
        } else if (num < 0) {
            document.getElementById("resp").textContent = "El número es negativo.";
        } else {
            document.getElementById("resp").textContent = "El número es cero.";
        }
    }


    //21. Año bisiesto: Solicita al usuario un año y determina si es un año bisiesto o no. Un año bisiesto es divisible por 4, pero no por 100, a menos que también sea divisible por 400.
bisiesto() {
        let año = parseInt(document.getElementById("num").value);
        if (año % 4 === 0 && (año % 100 !== 0 || año % 400 === 0)) {
            document.getElementById("resp").textContent = año + " es un año bisiesto.";
        } else {
            document.getElementById("resp").textContent = año + " no es un año bisiesto.";
        }
    }


   
    //22. Signo zodiacal: Pide al usuario que ingrese su mes y día de nacimiento, luego determina su signo zodiacal. Puedes usar una serie de declaraciones if para comparar las fechas ingresadas con las fechas límite de cada signo zodiacal.
    zodiaco() {
        let mes = parseFloat(document.getElementById("num").value);
        if (mes >= 1 && mes <= 12) {
            let dia = parseFloat(document.getElementById("num1").value);
            if (dia >= 1 && dia <= 31) {
                if ((mes === 3 && dia >= 21) || (mes === 4 && dia <= 19)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Aries."
                } else if ((mes === 4 && dia >= 20) || (mes === 5 && dia <= 20)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Tauro."
                } else if ((mes === 5 && dia >= 21) || (mes === 6 && dia <= 20)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Géminis."
                } else if ((mes === 6 && dia >= 21) || (mes === 7 && dia <= 22)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Cáncer."
                } else if ((mes === 7 && dia >= 23) || (mes === 8 && dia <= 22)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Leo."
                } else if ((mes === 8 && dia >= 23) || (mes === 9 && dia <= 22)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Virgo."
                } else if ((mes === 9 && dia >= 23) || (mes === 10 && dia <= 22)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Libra."
                } else if ((mes === 10 && dia >= 23) || (mes === 11 && dia <= 21)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Escorpio."
                } else if ((mes === 11 && dia >= 22) || (mes === 12 && dia <= 21)) {
                document.getElementById("resp").textContent = "Tu signo zodiacal es Sagitario."
                } else if ((mes === 12 && dia >= 22) || (mes === 1 && dia <= 19)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Capricornio."
                } else if ((mes === 1 && dia >= 20) || (mes === 2 && dia <= 18)) {
                    document.getElementById("resp").textContent = "Tu signo zodiacal es Acuario."
                } else if ((mes === 2 && dia >= 19) || (mes === 3 && dia <= 20)) {
                document.getElementById("resp").textContent = "Tu signo zodiacal es Piscis."
                } else {
                    document.getElementById("resp").textContent = "El día y mes ingresados no son válidos."
                }
            }else {
                document.getElementById("resp").textContent = "Ingrese bien la fecha, el día no es válido.";
            }
        } else {
            document.getElementById("resp").textContent = "Ingrese bien la fecha, el mes no es válido.";
        }
    }
    
    //23. Día del mes con respecto a la segunda quincena: Solicita al usuario que ingrese un número de día del mes (por ejemplo, del 1 al 31) y verifica si ese día pertenece a la primera quincena (días 1-15) o a la segunda quincena (días 16-31).
    quincena() {
        let dia = parseFloat(document.getElementById("num").value);
        if (dia >= 1 && dia <= 15) {
            document.getElementById("resp").textContent = "El día " + dia + " pertenece a la primera quincena.";
        } else if (dia >= 16 && dia <= 31) {
            document.getElementById("resp").textContent = "El día " + dia + " pertenece a la segunda quincena.";
        } else {
            document.getElementById("resp").textContent = "Día no válido. Ingresa un número entre 1 y 31.";
        }
    }

    //24. Día de la semana: Pide al usuario que ingrese un número del 1 al 7, donde 1 representa el domingo, 2 el lunes, 3 el martes, y así sucesivamente. Luego, utiliza una estructura switch para mostrar el nombre del día de la semana correspondiente al número ingresado.
    semana() {
        var numero = parseFloat(document.getElementById("num").value);
        switch (numero) {
            case 1:
                document.getElementById("resp").textContent = "Domingo"
                break;
            case 2:
                document.getElementById("resp").textContent = "Lunes"
                break;
            case 3:
                document.getElementById("resp").textContent = "Martes"
                break;
            case 4:
                document.getElementById("resp").textContent = "Miércoles"
                break;
            case 5:
                document.getElementById("resp").textContent = "Jueves"
                break;
            case 6:
                document.getElementById("resp").textContent = "Viernes"
                break;
            case 7:
                document.getElementById("resp").textContent = "Sábado"
                break;
            default:
                document.getElementById("resp").textContent = "Número inválido"
        }
    }
    

    //25. Frases iguales: Escribir un programa que ingrese dos frases e indique si son iguales
    frases() {
        let frase1 = prompt("Ingrese la primera frase:");
        let frase2 = prompt("Ingrese la segunda frase:");
        if (frase1 === frase2) {
            document.getElementById("resp").textContent = "Las frases son iguales.";
        } else {
            document.getElementById("resp").textContent = "Las frases no son iguales.";
        }
    }


    //26. Calculadora de precio con descuento: Crea un programa que permita a un usuario ingresar el precio de un artículo y un porcentaje de descuento. El programa debe calcular y mostrar el precio final después del descuento.
    descuento() {
        let precio = parseFloat(document.getElementById("num").value)
        let descuento = parseFloat(document.getElementById("num1").value)

        if (descuento >= 0 && descuento <= 100) {
            let precioFinal = precio - (precio * (descuento / 100));
            document.getElementById("resp").textContent = "El precio final después del descuento es: $" + precioFinal;
        } else {
            document.getElementById("resp").textContent = "El porcentaje de descuento ingresado no es válido.";
        }
    }


    //27. Calculadora de factura con impuestos: Solicita al usuario que ingrese el total de una factura y el porcentaje de impuestos aplicado. Luego, calcula y muestra el monto total a pagar, incluyendo los impuestos.
    impuesto() {
        let factura = parseFloat(document.getElementById("num").value)
        let impuestos = parseFloat(document.getElementById("num1").value)

        if (impuestos >= 0) {
            let monto = (factura * impuestos) / 100;
            let total = factura + monto;
            document.getElementById("resp").textContent = "El monto de impuestos es: $" + monto + "\nEl total a pagar, incluyendo los impuestos, es: $" + total;
        } else {
            document.getElementById("resp").textContent = "El porcentaje de impuestos ingresado no es válido.";
        }
    }


    //28. Calculadora de sueldo con aumento: Pide al usuario que ingrese su salario actual y el porcentaje de aumento que recibirá. Calcula y muestra el nuevo salario después del aumento.
    sueldo() {
        let salactual = parseFloat(document.getElementById("num").value)
        let aumento = parseFloat(document.getElementById("num1").value)
        if (aumento >= 0) {
            let nuevosalario = salactual + (salactual * (aumento / 100));
            document.getElementById("resp").textContent = "Su nuevo salario después del aumento es: $" + nuevosalario;
        } else {
            document.getElementById("resp").textContent = "El porcentaje de aumento ingresado no es válido";
        }
    }

 //29. Calculadora de compra con múltiples artículos: Permite al usuario ingresar el precio y la cantidad de varios artículos que está comprando. Calcula el total de la compra y aplica un descuento del 10% si el total es mayor a cierta cantidad (por ejemplo, $100)
    
 calcularTotal() {
    // Obtener los elementos del formulario
    let precios = document.getElementById("num").value.split(",").map(Number);
    let cantidades = document.getElementById("num1").value.split(",").map(Number);
    let total = 0;
    // Verificar que las longitudes de los arrays sean iguales
    if (precios.length !== cantidades.length) {
        document.getElementById("resp").textContent = "Error: Las listas de precios y cantidades deben tener la misma longitud.";
        return;
    }
    for (let i = 0; i < precios.length; i++) {
        total += precios[i] * cantidades[i];
    }
    if (total > 100) {
        total *= 0.9;
    }
    document.getElementById("resp").textContent = "Total de la compra: $" + total.toFixed(2);
}



    //30. Calculadora de impuestos sobre el salario: Solicita al usuario que ingrese su salario anual y calcula el impuesto sobre la renta según las siguientes tasas: Hasta $10,000: 5%
    //    De $10,001 a $20,000: 10% Más de $20,000: 15%
    salario() {
        let salarioanual = parseFloat(document.getElementById("num").value)
        let impuesto = 0;
        if (salarioanual <= 10000) {
            impuesto = salarioanual * 0.05;
        } else if (salarioanual >= 10001 && salarioanual <= 20000) {
            impuesto = salarioanual * 0.10;
        } else if (salarioanual > 20000) {
            impuesto = salarioanual * 0.15;
        }
        document.getElementById("resp").textContent = "Impuesto sobre la renta a pagar: $" + impuesto;
    }



    //31. Descuento por antigüedad en la empresa: Pregunta al usuario cuántos años ha estado trabajando en una empresa y calcula su bono de antigüedad. Si ha trabajado más de 5 años, otorga un bono del 5% sobre su salario.
    antiguedad() {
        let añosTrabajados = parseFloat(document.getElementById("num").value)
        let salario = parseFloat(document.getElementById("num1").value) 
        let bono = 0;
        if (añosTrabajados > 5) {
            bono = salario * 0.05;
        }
        document.getElementById("resp").textContent = "Bono de antigüedad a recibir: $" + bono;
    }



    //32. Calculadora de envío con tarifas diferentes: Crea un programa que permita al usuario ingresar la distancia de envío y calcule el costo del envío. Si la distancia es inferior a 50 km, el costo es de $10. Si la distancia es de 50 km o más, el costo es de $20.
    tarifa() {
        let distancia = parseFloat(document.getElementById("num").value)
        let envio;
        if (distancia < 50) {
            envio = 10;
        } else {
            envio = 20;
        }
        document.getElementById("resp").textContent = "El costo de envío es: $" + envio;
    }
    


    //33. Calculadora de descuento por lealtad del cliente: Pide al usuario que ingrese el total de sus compras mensuales durante un año. Si el total es superior a $500, aplica un descuento del 10% en la próxima compra.
    lealtad() {
        let total = parseFloat(document.getElementById("num").value)
        let descuento = total > 500 ? total * 0.10 : 0;
        document.getElementById("resp").textContent = "Total anual de compras: $" + total + "\nDescuento para la próxima compra: $" + descuento;
    }



    //34. Calculadora de descuento por volumen de compra: Permite al usuario ingresar la cantidad de unidades de un producto que va a comprar y el precio unitario. Aplica descuentos por volumen de compra según las siguientes reglas:
    //    10-50 unidades: 5% de descuento 51-100 unidades: 10% de descuento Más de 100 unidades: 15% de descuento
    volumen() {
        const cantidad = parseFloat(document.getElementById("num").value);
        const precioUnitario = parseFloat(document.getElementById("num1").value);
        if (!isNaN(cantidad) && !isNaN(precioUnitario)) {
            let descuento = 0;
            if (cantidad >= 10 && cantidad <= 50) {
                descuento = precioUnitario * cantidad * 0.05;
            } else if (cantidad > 50 && cantidad <= 100) {
                descuento = precioUnitario * cantidad * 0.10;
            } else if (cantidad > 100) {
                descuento = precioUnitario * cantidad * 0.15;
            }
            const precioTotal = precioUnitario * cantidad - descuento;
    
            document.getElementById("resp").textContent = "Precio total con descuento: $" + precioTotal.toFixed(2);
        } else {
            document.getElementById("resp").textContent = "Ingrese valores numéricos para cantidad y precio unitario.";
        }
    }
    

    //35. Calculadora de costo de servicio: Pregunta al usuario cuántas horas de servicio necesita y calcula el costo total. Si las horas son más de 10, aplica un descuento del 20%.
    servicio() {
        let horas = parseFloat(document.getElementById("num").value);
        let total;
        if (horas <= 10) {
            total = horas * 20;
        } else {
            total = horas * 20 - (horas * 20 * 0.20);
        }
        document.getElementById("resp").textContent = "Costo total del servicio: $" + total;
    }
}
const Ejercicios = new selectivo()