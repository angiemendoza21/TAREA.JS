class Arreglos {
    regresar() {
        window.history.back();
    }

    sumarElementos() {
        let resp, suma = 0, elementos;
        elementos = document.getElementById("num").value;
        elementos = elementos.split(";");
        for (let i = 0; i < elementos.length; i++) {
            suma += parseFloat(elementos[i]);
        }

        resp = document.getElementById("resp");
        resp.innerHTML = `La suma de los elementos es: ${suma}`;
    }

    calificaciones() {
        let resp, pro, acu = 0, pos, lon, notas;
        // Corrected the id to match the one in the HTML
        notas = document.getElementById("notas").value;
        notas = notas.split(";");
        lon = notas.length;
        for (pos = 0; pos < lon; pos++) {
            acu = acu + parseFloat(notas[pos]);
        }
        pro = acu / lon;
        pro = Math.round(pro * 100) / 100;
        resp = document.getElementById("resp");
        resp.innerHTML = `Promedio de Notas:[${notas}] = ${pro}`;
    }
    

    encontrarMayorMenor() {
        let resp, maximo, minimo, numeros;
        numeros = document.getElementById("num").value;
        numeros = numeros.split(";");
        if (numeros.length >= 2) {
            maximo = parseFloat(numeros[0]);
            minimo = parseFloat(numeros[0]);
            for (let i = 1; i < numeros.length; i++) {
                let num = parseFloat(numeros[i]);
                if (num > maximo) {
                    maximo = num;
                }
                if (num < minimo) {
                    minimo = num;
                }
            }
            resp = document.getElementById("resp");
            resp.innerHTML = `El valor máximo es ${maximo} y el valor mínimo es ${minimo}.`;
        } else {
            resp = document.getElementById("resp");
            resp.innerHTML = "Por favor, ingrese al menos dos números.";
        }
    }
    

    buscar() {
        let resp, numeros, numeroABuscar;
        let encontrado = false;
        numeros = document.getElementById("num").value;
        let arreglo = numeros.split(";").map(Number);
        numeroABuscar = document.getElementById("num1").value;
        if (!isNaN(numeroABuscar)) {
            numeroABuscar = parseFloat(numeroABuscar);
            encontrado = arreglo.includes(numeroABuscar);
            resp = document.getElementById("resp");
            if (encontrado) {
                resp.textContent = "El número " + numeroABuscar + " está en el arreglo.";
            } else {
                resp.textContent = "El número " + numeroABuscar + " no está en el arreglo.";
            }
        } else {
            resp = document.getElementById("resp");
            resp.textContent = "Por favor, ingrese un número válido.";
        }
    }


    pares() {
        let resp, numeros, contador = 0;
        numeros = document.getElementById("num").value;
        let arreglo = numeros.split(";").map(Number);
        for (let i = 0; i < arreglo.length; i++) {
            if (arreglo[i] % 2 === 0) {
                contador++;
            }
        }
        resp = document.getElementById("resp");
        resp.textContent = "Hay " + contador + " números pares en el arreglo.";
    }

    inversion() {
        let resp, numeros, invertido;
        numeros = document.getElementById("num").value;
        let arreglo = numeros.split(";").map(Number);
        console.log("El arreglo original es: " + arreglo.join(" "));
        invertido = [];
        for (let i = arreglo.length - 1; i >= 0; i--) {
            invertido.push(arreglo[i]);
        }
        resp = document.getElementById("resp");
        resp.textContent = "El arreglo invertido es: " + invertido.join(" ");
    }

    indice() {
        let resp, valor;
        let numeros = document.getElementById("num").value;
        let num = numeros.split(";").map(Number);
        valor = document.getElementById("num1").value;
        resp = document.getElementById("resp");
        if (valor !== "" && !isNaN(valor)) {
            valor = parseFloat(valor);
            if (num.includes(valor)) {
                resp.textContent = "El valor " + valor + " se encuentra en los índices: " + num.indexOf(valor);
            } else {
                resp.textContent = "El valor " + valor + " no se encuentra en el arreglo.";
            }
        } else {
            resp.textContent = "Por favor, ingrese un valor numérico.";
        }
    }
}

const Ejercicio_arreglos = new Arreglos();
