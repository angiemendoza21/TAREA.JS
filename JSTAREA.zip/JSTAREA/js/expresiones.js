class expresiones{

ejercicio1() {  
    let a = parseInt(document.getElementById("num").value)
    let b = parseInt(document.getElementById("num1").value)
    let resp;
    resp = 0;
    resp = (2 * a + b - 3) % 3;
    document.getElementById("resp").textContent =  "El resultado es: " + resp
}

ejercicio2() 
{
    let a= parseInt(document.getElementById('num').value);
    let b= parseInt(document.getElementById('num1').value);
    let z 
    z = 0
    z = (a * b + 3) % (a + b);
    document.getElementById("resp").textContent = "El resulado es "+ z
    
}

ejercicio3() 
{
    let a = parseInt(document.getElementById("num").value)
    let b = parseInt(document.getElementById("num1").value)
    let w
    w = a - b + 2 * (a % b);
    document.getElementById("resp").textContent = "El resulado es "+ w
    
}

ejercicio4() {

    let a = parseInt(document.getElementById("num").value)
    let b = parseInt(document.getElementById("num1").value)
    let v
    v = 2 * b + a / 2 + 4 * (b % a);
    document.getElementById("resp").textContent = "El resulado es "+ v
}

ejercicio5() {
    let a = parseInt(document.getElementById("num").value)
    let b = parseInt(document.getElementById("num1").value)
    let u
    u = b - a + 3 * (a % b);
    document.getElementById("resp").textContent = "El resulado es "+ u
}

ejercicio6() {
    let ejercicio;
    ejercicio = (5 + 3 * 2) + 9 > 3 * 5 * 14 % 3;
    document.getElementById("resp").textContent = "El resultado es " + ejercicio;    
}

ejercicio7() {
    let ejercicio;
    ejercicio = 2 * (4 - 10 + 8) / 2 * 36 * (1 / 2);
    document.getElementById("resp").textContent = "El resultado es " + ejercicio;  
}


ejercicio8() {
    let ejercicio;
    ejercicio = 260 / 12 + 54 % 3 - 85 % 7;
    document.getElementById("resp").textContent = "El resultado es " + ejercicio;
}


ejercicio9() {
    let ejercicio;
    ejercicio = (48 < 2 * 3) || (2 * 7 < 12);
    document.getElementById("resp").textContent = "El resultado es " + ejercicio;
}

ejercicio10() {
    let ejercicio;
    ejercicio = ((8 > 2) || (932 < 23)) && (4 == 2);
    document.getElementById("resp").textContent = "El resultado es " + ejercicio;
}

regresar(){
    window.history.back();
}
}
const Ejercicios_expreciones = new expresiones()