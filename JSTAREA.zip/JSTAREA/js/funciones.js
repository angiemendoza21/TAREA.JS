
function regresar(){
    window.history.back();
}

// 58. Función sin parámetros para saludar.
function saludar() {
    document.getElementById("resp").textContent =  "¡Hola! Bienvenido"
}


// 59. Función con parámetros para sumar dos números.

function sumar(num1, num2) {
    if (!isNaN(num1) && !isNaN(num2)) {
        let respuesta = num1 + num2;
        document.getElementById("resp").textContent = "La suma de los números es " + respuesta;
    } else {
        document.getElementById("resp").textContent = "Por favor, ingrese números válidos en ambos campos.";
    }
}
function realizarSuma() {
    let num1 = parseInt(document.getElementById("num").value);
    let num2 = parseInt(document.getElementById("num1").value);
    sumar(num1, num2);
}


// 60. Función con return para multiplicar dos números.


function multiplicar(n1, n2){
    let resp = n1 * n2; 
    return resp;        
}

function realizarMultiplicacion() {
    let num1 = parseInt(document.getElementById("num").value);
    let num2 = parseInt(document.getElementById("num1").value);

    let resultado = multiplicar(num1, num2);
    document.getElementById("resp").textContent = "El resultado de la multiplicación es: " + resultado;
}


// 61. Función sin return para determinar si un número es par o impar.

function parImpar(num) {
    if (num % 2 === 0) {
        document.getElementById("resp").textContent = "El número es par";
    } else {
        document.getElementById("resp").textContent = "El número es impar";
    }
}

function determinarParImpar() {
    let num = parseInt(document.getElementById("num").value);
    if (!isNaN(num)) {
        parImpar(num);
    } else {
        document.getElementById("resp").textContent = "Por favor, ingresa un número válido.";
    }
}

// 62. Función con parámetros y return para calcular el área de un rectángulo.

function calcularAreaRectangulo(base, altura) {
    let area = base * altura;
    return area;
}

function calculo(){
    let baseRectangulo = parseFloat(document.getElementById("num").value)
    let alturaRectangulo = parseFloat(document.getElementById("num").value)
    let areaCalculada = calcularAreaRectangulo(baseRectangulo, alturaRectangulo);
    document.getElementById("resp").textContent = "El área del rectángulo es: " + areaCalculada
}


// 63. Función sin parámetros para imprimir tu nombre.
function imprimirNombre() {
    let nombre = String(document.getElementById("num").value)
   document.getElementById("resp").textContent = "Mi nombre es: " + nombre
}



// 64. Función con return para convertir grados Celsius a Fahrenheit.

function convertirAFahrenheit() {
    let celsius = parseFloat(document.getElementById("num").value);
    let fahrenheit = (celsius * 9/5) + 32;
    document.getElementById("resp").textContent = "La temperatura en grados Fahrenheit es: " + fahrenheit;
    return fahrenheit;
}

// 65. Función con parámetros para contar un carácter en una frase.

function contarCaracteres(frase) {
    longitud = frase.length;
}

let longitud; 
function palabra() {
    let frase = document.getElementById("num").value;
    contarCaracteres(frase); 
    document.getElementById("resp").textContent = "La frase tiene: " + longitud + " caracteres";
}


// 66. Función sin return para imprimir números del 1 al 10.


function imprimirNumeros() {
    let resultado = " ";
    for (let num = 1; num <= 10; num++) {
        resultado += num + "";
        document.getElementById("resp").textContent = resultado;
    }
}

// 67. Función con parámetros y return para sumar una lista de números.
let numeros = [];
function sumarListaNumeros() {
    let num = document.getElementById("num").value;

    // Verificar si la entrada contiene solo números y comas
    if (/^\d+(,\s*\d+)*$/.test(num)) {
        // Dividir la cadena en números
        let numerosArray = num.split(",").map(Number);

        // Agregar los números al array 'numeros'
        numeros = numeros.concat(numerosArray);

        // Calcular la suma de los números
        let suma = numeros.reduce((total, numero) => total + numero, 0);

        // Mostrar la suma en el elemento con el id "resp"
        document.getElementById("resp").textContent = "La suma de los números es: " + suma;
    } else {
        // Manejar el caso en que la entrada no sea válida
        document.getElementById("resp").textContent = "Por favor, ingrese una lista válida de números separados por comas.";
    }
}

